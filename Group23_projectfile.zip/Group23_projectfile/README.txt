﻿
Hello Teacher ,

We have export our project file to html type. (From the .mp to .html)
The tool we use to design was the Mockplus, the project fiel was .mp.

You can open the index.html then you can check our work. 


Last,we are really sorry for wasting some time to connect to the projector before the  presentation.
We should export the html file earlier before the class. 
It was my negligence, because we did not recognize that the program we use to design is not free, which charge some money.

Now it is ok. Thanks.







